package modelo;

public class Estudante {

	
		 private int id;
		    private String nome;
		    private String curso;
		    private double nota;

		    public Estudante(String nome, String curso, double nota) {
		        this(0, nome, curso, nota);
		    }

		    public Estudante(int id, String nome, String curso, double nota) {
		        this.id = id;
		        this.nome = nome;
		        this.curso = curso;
		        this.nota = nota;
		    }

		    public int getId() {
		        return id;
		    }

		    public void setId(int id) {
		        this.id = id;
		    }

		    public String getNome() {
		        return nome;
		    }

		    public void setNome(String nome) {
		        this.nome = nome;
		    }

		    public String getCurso() {
		        return curso;
		    }

		    public void setCurso(String curso) {
		        this.curso = curso;
		    }

		    public double getNota() {
		        return nota;
		    }

		    public void setNota(double nota) {
		        this.nota = nota;
		    }

		    @Override
		    public String toString() {
		        return "Estudante[id=" + id +
		               ", nome=" + nome +
		               ", curso=" + curso +
		               ", nota=" + nota + "]";
		    }
		

	}



package visao;

import java.awt.EventQueue;
import java.sql.SQLException;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;

import dao.EstudanteDAO;
import modelo.Estudante;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTable;
import javax.swing.SwingConstants;
public class JanelaEstudante extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtNome;
	private JTextField txtCurso;
	private JTextField txtNota;
	private JTextField txtBuscar;
	private JTable table;
	private JButton btnCadastrar;
	private JButton btnAlterar;
	private JButton btnExcluir;
	private JButton btnLimpar;
	private JButton btnLimparDados;
	private JButton btnBuscar;
	private JLabel lblStatus;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					JanelaEstudante frame = new JanelaEstudante();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public JanelaEstudante() {
		
		
		
		DefaultTableModel modelo;

		final EstudanteDAO dao = new EstudanteDAO();

		int idSelecionado = 0;
		
		
		
		
		
		
		
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Nome:");
		lblNewLabel.setBounds(25, 11, 46, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("curso:");
		lblNewLabel_1.setBounds(207, 11, 46, 14);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("nota:");
		lblNewLabel_2.setBounds(25, 36, 46, 14);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("buscar:");
		lblNewLabel_3.setBounds(207, 36, 46, 14);
		contentPane.add(lblNewLabel_3);
		
		txtNome = new JTextField();
		txtNome.setBounds(93, 8, 86, 20);
		contentPane.add(txtNome);
		txtNome.setColumns(10);
		
		txtCurso = new JTextField();
		txtCurso.setBounds(263, 8, 86, 20);
		contentPane.add(txtCurso);
		txtCurso.setColumns(10);
		
		txtNota = new JTextField();
		txtNota.setBounds(93, 33, 86, 20);
		contentPane.add(txtNota);
		txtNota.setColumns(10);
		
		txtBuscar = new JTextField();
		txtBuscar.setBounds(263, 33, 86, 20);
		contentPane.add(txtBuscar);
		txtBuscar.setColumns(10);
		
		btnCadastrar = new JButton("cadastrar");
		btnCadastrar.setBounds(25, 76, 115, 23);
		contentPane.add(btnCadastrar);
		
		btnAlterar = new JButton("alterar");
		btnAlterar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnAlterar.setBounds(25, 110, 115, 23);
		contentPane.add(btnAlterar);
		
		btnExcluir = new JButton("excluir");
		btnExcluir.setBounds(25, 144, 115, 23);
		contentPane.add(btnExcluir);
		
		btnLimpar = new JButton("limpar");
		btnLimpar.setBounds(207, 76, 115, 23);
		contentPane.add(btnLimpar);
		
		btnLimparDados = new JButton("limpar dados");
		btnLimparDados.setBounds(207, 110, 115, 23);
		contentPane.add(btnLimparDados);
		
		btnBuscar = new JButton("buscar");
		btnBuscar.setBounds(207, 144, 115, 23);
		contentPane.add(btnBuscar);
		
		table = new JTable();
		table.setBounds(0, -5, 434, 230);
		contentPane.add(table);
		
		lblStatus = new JLabel("pronto");
		lblStatus.setBounds(187, 236, 46, 14);
		contentPane.add(lblStatus);
		
		
		
		
		
		
		
		
		
		

	}
	public JTextField getTxtNome() {
		return txtNome;
	}
	public JTextField getTxtNota() {
		return txtNota;
	}
	public JTextField getTxtCurso() {
		return txtCurso;
	}
	public JTextField getTxtBuscar() {
		return txtBuscar;
	}
	public JButton getBtnCadastrar() {
		return btnCadastrar;
	}
	public JButton getBtnAlterar() {
		return btnAlterar;
	}
	public JButton getBtnExcluir() {
		return btnExcluir;
	}
	public JButton getBtnLimpar() {
		return btnLimpar;
	}
	public JButton getBtnLimparDados() {
		return btnLimparDados;
	}
	public JButton getBtnBuscar() {
		return btnBuscar;
	}
	public JTable getTable() {
		return table;
	}
	public JLabel getLblSatatus() {
		return lblStatus;
	}
	
	private DefaultTableModel modelo;

	private final EstudanteDAO dao = new EstudanteDAO();

	private int idSelecionado = 0;
	
	
}

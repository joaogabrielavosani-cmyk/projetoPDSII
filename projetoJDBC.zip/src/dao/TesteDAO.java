package dao;



		import modelo.Estudante;

		public class TesteDAO {

		    public static void main(String[] args) throws Exception {

		        EstudanteDAO dao = new EstudanteDAO();

		        System.out.println("=== LISTAR ===");

		        for (Estudante e : dao.listar()) {
		            System.out.println(e);
		        }

		        System.out.println("\n=== INSERIR ===");

		        Estudante novo =
		                new Estudante("Diego Alves", "ADS", 8.0);

		        dao.inserir(novo);

		        System.out.println("Novo estudante:");
		        System.out.println(novo);

		        System.out.println("\n=== ALTERAR ===");

		        novo.setNota(9.5);

		        System.out.println(
		            "Alterou: " + dao.alterar(novo)
		        );

		        System.out.println("\n=== BUSCAR ===");

		        for (Estudante e : dao.buscarPorNome("li")) {
		            System.out.println(e);
		        }

		        System.out.println("\n=== EXCLUIR ===");

		        System.out.println(
		            "Excluiu: " + dao.excluir(novo.getId())
		        );
		    }
		
	}


